configuration files are per-directory.
- the main folder is the current repo of the config files
- when the new configuration files are uploaded, a new directory is created with current timestamp and everything in main folder is moved.  Main folder has new configuration files
